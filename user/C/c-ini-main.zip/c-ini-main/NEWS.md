# c-ini - Ini-File Handling

## CHANGES WITH 1:

        * Initial release of c-ini.

        * TBD

        Contributions from: TBD

        - TBD, YYYY-MM-DD
