/* SPDX-License-Identifier: GPL-2.0-or-later */
/*
 * INET		An implementation of the TCP/IP protocol suite for the LINUX
 *		operating system.  INET is implemented using the  BSD Socket
 *		interface as the means of communication with the user level.
 *
 *		Definitions for the ICMP module.
 *
 * Version:	@(#)icmp.h	1.0.4	05/13/93
 *
 * Authors:	Ross Biro
 *		Fred N. van Kempen, <waltje@uWalt.NL.Mugnet.ORG>
 */
#ifndef _dof_H
#define	_dof_H

#include <linux/icmp.h>

#include <net/inet_sock.h>
#include <net/snmp.h>
#include <net/ip.h>

struct dof_err {
  int		errno;
  unsigned int	fatal:1;
};

extern const struct dof_err dof_err_convert[];
#define dof_INC_STATS(net, field)	SNMP_INC_STATS((net)->mib.dof_statistics, field)
#define __dof_INC_STATS(net, field)	__SNMP_INC_STATS((net)->mib.dof_statistics, field)
#define ICMPMSGOUT_INC_STATS(net, field)	SNMP_INC_STATS_ATOMIC_LONG((net)->mib.icmpmsg_statistics, field+256)
#define ICMPMSGIN_INC_STATS(net, field)		SNMP_INC_STATS_ATOMIC_LONG((net)->mib.icmpmsg_statistics, field)

struct dst_entry;
struct net_proto_family;
struct sk_buff;
struct net;

void __dof_send(struct sk_buff *skb_in, int type, int code, __be32 info,
		 const struct ip_options *opt);
static inline void dof_send(struct sk_buff *skb_in, int type, int code, __be32 info)
{
	__dof_send(skb_in, type, code, info, &IPCB(skb_in)->opt);
}

#if IS_ENABLED(CONFIG_NF_NAT)
void dof_ndo_send(struct sk_buff *skb_in, int type, int code, __be32 info);
#else
static inline void dof_ndo_send(struct sk_buff *skb_in, int type, int code, __be32 info)
{
	struct ip_options opts = { 0 };
	__dof_send(skb_in, type, code, info, &opts);
}
#endif

int dof_rcv(struct sk_buff *skb);
int dof_err(struct sk_buff *skb, u32 info);
int dof_init(void);
void dof_out_count(struct net *net, unsigned char type);
bool dof_build_probe(struct sk_buff *skb, struct icmphdr *icmphdr);

#endif	/* _dof_H */
