/* ebt_cfe */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "../include/ebtables_u.h"
#include <linux/netfilter_bridge/ebt_cfe.h>

#define FWD_STRING     '1'
#define ACC_STRING     '2'
#define QID_IDX        '3'
#define PQ_VAL         '4'
#define GRO_ID         '5'
#define SPRI_VAL       '6'

#define OPT_FWD_STRING 0x01
#define OPT_ACC_STRING 0x02
#define OPT_QID_IDX    0x04
#define OPT_PQ_VAL     0x08
#define OPT_GRO_ID     0x10
#define OPT_SPRI_VAL   0x20

static struct option opts[] =
{
    { "fwd", required_argument, NULL, FWD_STRING },
    { "acc", required_argument, NULL, ACC_STRING },
    { "qid", required_argument, NULL, QID_IDX },
    { "pq",  required_argument, NULL, PQ_VAL },
    { "gro_id", required_argument, NULL, OPT_GRO_ID },
    { "spri", required_argument, NULL, SPRI_VAL },
    { 0 }
};

static void print_help()
{
	printf("cfe qos target options:\n"
           "  --fwd accept or drop, accept by default\n"
           "  --acc yes or no, yes by default\n"
           "  --qid must allocate first, as index specify a qid entry\n"
           "  --pq  specify pq modify value, in range [0,7]\n"
           "  --gro_id specify a gro id\n"
           "  --spri specify outer 802.1p, in range [0,7]\n"
           "\n");
    return;
}

static void init(struct ebt_entry_target *target)
{
    struct ebt_cfe_info *info = (struct ebt_cfe_info *)target->data;

    strncpy(info->fwd, "accept", FWD_MAX_LEN - 1);
    strncpy(info->acc, "yes",    ACC_MAX_LEN - 1);
    info->qid = HI_CFE_INVALID_QID;
    info->pq  = HI_CFE_INVALID_PQ;
    info->gro_id = HI_CFE_INVALID_GRO_ID;
    info->spri = HI_CFE_INVALID_SPRI;
    return;
}

static int parse(int c, char **argv, int argc, const struct ebt_u_entry *entry,
                 unsigned int *flags, struct ebt_entry_target **target)
{
	struct ebt_cfe_info *info = (struct ebt_cfe_info *)(*target)->data;
	char *end = 0;

	switch (c) {
    	case FWD_STRING:
            ebt_check_option2(flags, OPT_FWD_STRING);
    		strncpy(info->fwd, (char *)optarg, FWD_MAX_LEN - 1);
            break;
    	case ACC_STRING:
            ebt_check_option2(flags, OPT_ACC_STRING);
    		strncpy(info->acc, (char *)optarg, ACC_MAX_LEN - 1);
    		break;
    	case QID_IDX:
            ebt_check_option2(flags, OPT_QID_IDX);
            info->qid = strtoul(optarg, end, 0);
    		break;
    	case PQ_VAL:
            ebt_check_option2(flags, OPT_PQ_VAL);
            info->pq = strtoul(optarg, end, 0);
    		break;
    	case GRO_ID:
            ebt_check_option2(flags, OPT_GRO_ID);
            info->gro_id = strtoul(optarg, end, 0);
    		break;
    	case SPRI_VAL:
            ebt_check_option2(flags, OPT_SPRI_VAL);
            info->spri = strtoul(optarg, end, 0);
    		break;
    	default:
    		return 0;
	}
	return 1;
}

static void final_check(const struct ebt_u_entry *entry, const struct ebt_entry_target *target,
                        const char *name, unsigned int hookmask, unsigned int time)
{
    return;
}

static void print(const struct ebt_u_entry *entry, const struct ebt_entry_target *target)
{
    char pq[6] = {0};
    char spri[6] = {0};
    char gro[6] = {0};
    struct ebt_cfe_info *info = (struct ebt_cfe_info *)target->data;

    if (info->pq >= HI_CFE_INVALID_PQ){
        sprintf(pq, "no");
    }else {
        sprintf(pq, "%u", info->pq);
    }

    if (info->gro_id >= HI_CFE_INVALID_GRO_ID){
        sprintf(gro, "no");
    }else {
        sprintf(gro, "%u", info->gro_id);
    }

    if (info->spri >= HI_CFE_INVALID_SPRI){
        sprintf(spri, "no");
    }else {
        sprintf(spri, "%u", info->spri);
    }

	printf(" fwd:%s acc:%s qid:%u pq:%s gro:%s spri:%s",
	    info->fwd, info->acc, info->qid, pq, gro, spri);
    return;
}

static int compare(const struct ebt_entry_target *t1, const struct ebt_entry_target *t2)
{
    struct ebt_cfe_info *info1 = (struct ebt_cfe_info *)t1->data;
    struct ebt_cfe_info *info2 = (struct ebt_cfe_info *)t2->data;

    if (memcmp(info1, info2, sizeof(struct ebt_cfe_info)) == 0)
        return 1;
    else
        return 0;
}

static struct ebt_u_target cfe_target =
{
    .name        = EBT_CFE_TARGET,
    .size        = sizeof(struct ebt_cfe_info),
    .help        = print_help,
    .init        = init,
    .parse       = parse,
    .final_check = final_check,
    .print       = print,
    .compare     = compare,
    .extra_ops   = opts,
};

static void _INIT(void)
{
    ebt_register_target(&cfe_target);
}
