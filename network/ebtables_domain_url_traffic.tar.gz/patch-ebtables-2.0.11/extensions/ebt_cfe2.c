#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "../include/ebtables_u.h"
#include <linux/netfilter_bridge/ebt_cfe2.h>

#define CFE_ID '1'
#define FWD_FLAG '2'
#define RATE '3'
#define PQ_VAL '4'
#define WAN_ID '5'
#define SPRI_VAL '6'

enum {
	OPT_CFE_ID = 1,
	OPT_FWD_FLAG,
	OPT_RATE,
	OPT_PQ_VAL,
	OPT_WAN_ID,
	OPT_SPRI_VAL,
};

static struct option opts[] =
{
	{ "cfe_id", required_argument, NULL, CFE_ID },
	{ "fwd", required_argument, NULL, FWD_FLAG },
	{ "rate", required_argument, NULL, RATE },
	{ "pq",	required_argument, NULL, PQ_VAL },
	{ "wan_id", required_argument, NULL, WAN_ID },
	{ "spri", required_argument, NULL, SPRI_VAL },
	{ 0 }
};

static void print_help()
{
	printf("cfe2 qos target options:\n"
		"  --cfe_id cfe flow id from [0, 65535]\n"
		"  --fwd fwd flag( bit0 not acc, bit1 flow cnt, bit2 dscp remark) \n"
		"  --rate rate limit value, in kbps\n"
		"  --pq  specify pq modify value, in range [0,7]\n"
		"  --wan_id specify a wan connection id\n"
		"  --spri specify outer 802.1p, in range [0,7]\n"
		"\n");
	return;
}

static void init(struct ebt_entry_target *target)
{
	struct ebt_cfe_info *info = (struct ebt_cfe_info *)target->data;

	info->cfe_id = 0;
	info->fwd_flag = 0;
	info->rate = 0;
	info->pq = HI_CFE_INVALID_PQ;
	info->wan_id = HI_CFE_INVALID_WAN_ID;
	info->spri = HI_CFE_INVALID_SPRI;
	return;
}

static int parse(int c, char **argv, int argc, const struct ebt_u_entry *entry,
	unsigned int *flags, struct ebt_entry_target **target)
{
	struct ebt_cfe_info *info = (struct ebt_cfe_info *)(*target)->data;
	char *end = 0;

	switch (c) {
	case CFE_ID:
		ebt_check_option2(flags, OPT_CFE_ID);
		info->cfe_id = strtoul(optarg, end, 0);
		break;
	case OPT_FWD_FLAG:
		ebt_check_option2(flags, OPT_FWD_FLAG);
		info->fwd_flag = strtoul(optarg, end, 0);
		break;
	case RATE:
		ebt_check_option2(flags, OPT_RATE);
		info->rate = strtoul(optarg, end, 0);
		break;
	case PQ_VAL:
		ebt_check_option2(flags, OPT_PQ_VAL);
		info->pq = strtoul(optarg, end, 0);
		break;
	case WAN_ID:
		ebt_check_option2(flags, OPT_WAN_ID);
		info->wan_id = strtoul(optarg, end, 0);
		break;
	case SPRI_VAL:
		ebt_check_option2(flags, OPT_SPRI_VAL);
		info->spri = strtoul(optarg, end, 0);
		break;
	default:
		return 0;
	}
	return 1;
}

static void final_check(const struct ebt_u_entry *entry,
	const struct ebt_entry_target *target, const char *name,
	unsigned int hookmask, unsigned int time)
{
	return;
}

static void print(const struct ebt_u_entry *entry,
	const struct ebt_entry_target *target)
{
	struct ebt_cfe_info *info = (struct ebt_cfe_info *)target->data;

	printf(" CFE_ID:%u");

	if (info->fwd_flag & FWD_ACC_DISABLE) {
		printf(" no_acc");
	}
	if (info->fwd_flag & FWD_CNT_ENABLE) {
		printf(" hw_cnt");
	}
	if (info->pq >= HI_CFE_INVALID_PQ) {
		printf(" pq %u", info->pq);
	}
	if (info->pq >= HI_CFE_INVALID_SPRI) {
		printf(" pri %u", info->spri);
	}
	if (info->rate > 0) {
		printf(" rate %u", info->rate);
	}
	if (info->wan_id > 0) {
		printf(" wan %u", info->wan_id);
	}
	return;
}

static int compare(const struct ebt_entry_target *t1,
	const struct ebt_entry_target *t2)
{
	struct ebt_cfe_info *info1 = (struct ebt_cfe_info *)t1->data;
	struct ebt_cfe_info *info2 = (struct ebt_cfe_info *)t2->data;

	if (memcmp(info1, info2, sizeof(struct ebt_cfe_info)) == 0)
		return 1;
	else
		return 0;
}

static struct ebt_u_target cfe_target = {
	.name = EBT_CFE_TARGET,
	.size = sizeof(struct ebt_cfe_info),
	.help = print_help,
	.init = init,
	.parse = parse,
	.final_check = final_check,
	.print = print,
	.compare = compare,
	.extra_ops = opts,
};

static void _INIT(void)
{
	ebt_register_target(&cfe_target);
}
