#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "../include/ebtables_u.h"
#include <linux/netfilter_bridge/ebt_domain_tgt.h>

#define REPLY_IP     '1'
#define REPLY_IPV6   '2'

static const struct option opts[] =
{
	{ "dnsreply-ip" ,        required_argument, 0, REPLY_IP},
	{ "dnsreply-ipv6" ,      required_argument, 0, REPLY_IPV6},
	{ 0 }
};

static void print_help()
{
	printf(
	"dnsreply target options:\n"
	" --dnsreply-ip          : ACCEPT, DROP, RETURN or CONTINUE\n"
	" --dnsreply-ipv6        : ACCEPT, DROP, RETURN or CONTINUE\n"
	"                                 (standard target is DROP)\n");
}

static void init(struct ebt_entry_target *target)
{
	struct ebt_dnsreply_info *replyinfo =
		(struct ebt_dnsreply_info *)target->data;

	memset(replyinfo->ip, 0, MAX_IP_STR_LEN);
	memset(replyinfo->ipv6, 0, MAX_IPV6_STR_LEN);

	return;
}

#define OPT_REPLY_IP       0x01
#define OPT_REPLY_IPV6     0x02
static int parse(int c, char **argv, int argc,
   const struct ebt_u_entry *entry, unsigned int *flags,
   struct ebt_entry_target **target)
{
	struct ebt_dnsreply_info *replyinfo =
		(struct ebt_dnsreply_info *)(*target)->data;

	switch (c) {
	case REPLY_IP:
		ebt_check_option2(flags, OPT_REPLY_IP);
		strncpy(replyinfo->ip, (char *)optarg, MAX_IP_STR_LEN - 1);
		break;

	case REPLY_IPV6:
		ebt_check_option2(flags, OPT_REPLY_IPV6);
		strncpy(replyinfo->ipv6, (char *)optarg, MAX_IPV6_STR_LEN - 1);
		break;

	default:
		return 0;
	}

	return 1;
}

static void final_check(const struct ebt_u_entry *entry,
   const struct ebt_entry_target *target, const char *name,
   unsigned int hookmask, unsigned int time)
{
	return;
}

static void print(const struct ebt_u_entry *entry,
   const struct ebt_entry_target *target)
{
	struct ebt_dnsreply_info *replyinfo =
		(struct ebt_dnsreply_info *)target->data;

	printf("--dnsreply-ip:%s ", replyinfo->ip);
	printf("--dnsreply-ipv6:%s ", replyinfo->ipv6);

	return;
}

static int compare(const struct ebt_entry_target *t1,
   const struct ebt_entry_target *t2)
{
	struct ebt_dnsreply_info *replyinfo1 = (struct ebt_dnsreply_info *)t1->data;
	struct ebt_dnsreply_info *replyinfo2 = (struct ebt_dnsreply_info *)t2->data;

	return ((0 == memcmp(replyinfo1->ip, replyinfo2->ip, MAX_IP_STR_LEN)) ||
			(0 == memcmp(replyinfo1->ipv6, replyinfo2->ipv6, MAX_IPV6_STR_LEN)));
}

static struct ebt_u_target dnsreply_target =
{
	.name		= "dnsreply",
	.size		= sizeof(struct ebt_dnsreply_info),
	.help		= print_help,
	.init		= init,
	.parse		= parse,
	.final_check	= final_check,
	.print		= print,
	.compare	= compare,
	.extra_ops	= opts,
};

static void _INIT(void)
{
	ebt_register_target(&dnsreply_target);
}

