#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include "../include/ebtables_u.h"
#include <linux/netfilter_bridge/ebt_traffic.h>

#define TRAFFIC_INDEX '1'
#define TRAFFIC_MODE '2'

static struct option opts[] = {
	{ "index", required_argument, 0, TRAFFIC_INDEX},
	{ "mode",  required_argument, 0, TRAFFIC_MODE},
	{ 0 }
};

static void print_help()
{
	printf("TAFFIC target options:\n"
	       "  --index INDEX    The index of rule ,this will return to APP\n"
	       "TAFFIC target options:\n"
	       "  --mode MODE     0: http process 1: mirror process 2:qos 3: monitor "
	       "4:monitor 5 vpn\n"
	       "\n");
}

static void init(struct ebt_entry_target *target)
{
	struct ebt_traffic_info *trafficinfo =
		(struct ebt_traffic_info *)target->data;

	trafficinfo->index = 0;
	trafficinfo->mode = 0;
	return;
}

#define OPT_TRAFFIC_INDEX 0x01
#define OPT_TRAFFIC_MODE 0x02
static int parse(int c, char **argv, int argc, const struct ebt_u_entry *entry,
		 unsigned int *flags, struct ebt_entry_target **target)
{
	struct ebt_traffic_info *trafficinfo =
		(struct ebt_traffic_info *)(*target)->data;
	char *end = 0;

	switch (c) {
	case TRAFFIC_INDEX:
		ebt_check_option2(flags, OPT_TRAFFIC_INDEX);
		trafficinfo->index = strtoul(optarg, end, 0);
		break;

	case TRAFFIC_MODE:
		ebt_check_option2(flags, OPT_TRAFFIC_MODE);
		trafficinfo->mode = strtoul(optarg, end, 0);
		break;
	default:
		return 0;
	}
	return 1;
}

static void final_check(const struct ebt_u_entry *entry,
			const struct ebt_entry_target *target, const char *name,
			unsigned int hookmask, unsigned int time)
{}

static void print(const struct ebt_u_entry *entry,
		  const struct ebt_entry_target *target)
{
	struct ebt_traffic_info *trafficinfo =
		(struct ebt_traffic_info *)target->data;

	printf("--mode %d --index %d ", trafficinfo->mode, trafficinfo->index);
}

static int compare(const struct ebt_entry_target *t1,
		   const struct ebt_entry_target *t2)
{
	struct ebt_traffic_info *info1 = (struct ebt_traffic_info *)t1->data;
	struct ebt_traffic_info *info2 = (struct ebt_traffic_info *)t2->data;

	if (memcmp(info1, info2, sizeof(struct ebt_traffic_info)) == 0)
		return 1;
	else
		return 0;
}

static struct ebt_u_target traffic_target = {
	.name = "TRAFFIC",
	.size = sizeof(struct ebt_traffic_info),
	.help = print_help,
	.init = init,
	.parse = parse,
	.final_check = final_check,
	.print = print,
	.compare = compare,
	.extra_ops = opts,
};

static void _INIT(void)
{
	ebt_register_target(&traffic_target);
}
