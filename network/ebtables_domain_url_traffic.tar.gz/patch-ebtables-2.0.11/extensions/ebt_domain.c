#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <getopt.h>
#include <ctype.h>
#include "../include/ebtables_u.h"
#include "../include/ethernetdb.h"
#include <linux/netfilter_bridge/ebt_domain.h>

#define DOMAIN_NAME '1'
#define MATCH_MODE '2'
#define MATCH_DIR '3'
#define MATCH_TYPE '4'
#define FILTER_INDEX '5'
#define FILTER_MODE '6'

static struct option opts[] = {
	{"name",         required_argument, NULL, DOMAIN_NAME},
	{"match-mode",   required_argument, NULL, MATCH_MODE},
	{"match-dir",    required_argument, NULL, MATCH_DIR},
	{"match-type",   required_argument, NULL, MATCH_TYPE},
	{"filter-index", required_argument, NULL, FILTER_INDEX},
	{"filter-mode",  required_argument, NULL, FILTER_MODE},
	{ 0 }
};

static void print_help()
{
	printf("domain match options:\n"
	       "--match-dir  DIR    IP address of Domain in direction(1 for up, 2 for "
	       "down, 3 for both(default)\n"
	       "--match-type TYPE   Match type, 1 for ip address in NO DNS Pkt , 2 "
	       "domain name in DNS pkt, 3 for both(default) and 4 for dns filter\n"
	       "--match-mode MODE   Match mode, 0 for full match(default), 1 for sub "
	       "match\n"
	       "--name NAME   Match a domain name in dns reply pkt\n"
	       "--filter-index FILTER_INDEX DNS filter index, 0xffffffff(default)\n"
	       "--filter-mode  FILTER_MODE  DNS filter mode, 0 for blacklist(default), 1 for whitelist\n");
}

static void init(struct ebt_entry_match *match)
{
	ebt_domain_info *domaininfo = (ebt_domain_info *)match->data;

	domaininfo->domain_name[0] = 0;
	domaininfo->match_dir = 3;
	domaininfo->match_mode = 0;
	domaininfo->match_type = 3;
	domaininfo->dnsfilter_index = 0xffffffff;
	domaininfo->dnsfilter_mode = 0;
}

#define OPT_NAME 0x1
#define OPT_MATCH_MODE 0x2
#define OPT_MATCH_DIR 0x4
#define OPT_MATCH_TYPE 0x8
#define OPT_MATCH_FILTER_INDEX 0x10
#define OPT_MATCH_FILTER_MODE 0x20

static int parse(int c, char **argv, int argc, const struct ebt_u_entry *entry,
		 unsigned int *flags, struct ebt_entry_match **match)
{
	ebt_domain_info *domaininfo = (ebt_domain_info *)(*match)->data;

	char *end = 0;
	switch (c) {
	case DOMAIN_NAME:
		ebt_check_option2(flags, OPT_NAME);
		printf("%s %d domain_name = %s para = %s, %p\n", __func__, __LINE__,
		       domaininfo->domain_name, optarg, optarg);
		strncpy(domaininfo->domain_name, (char *)optarg,
			sizeof(domaininfo->domain_name));
		break;

	case MATCH_MODE:
		ebt_check_option2(flags, OPT_MATCH_MODE);
		printf("%s %d domain_name = %s para = %s, %p\n", __func__, __LINE__,
		       domaininfo->domain_name, optarg, optarg);
		domaininfo->match_mode = strtoul(optarg, &end, 10);
		break;

	case MATCH_DIR:
		ebt_check_option2(flags, OPT_MATCH_DIR);
		domaininfo->match_dir = strtoul(optarg, &end, 10);
		break;

	case MATCH_TYPE:
		ebt_check_option2(flags, OPT_MATCH_TYPE);
		domaininfo->match_type = strtoul(optarg, &end, 10);
		break;

	case FILTER_INDEX:
		ebt_check_option2(flags, OPT_MATCH_FILTER_INDEX);
		domaininfo->dnsfilter_index = strtoul(optarg, &end, 10);
		break;

	case FILTER_MODE:
		ebt_check_option2(flags, OPT_MATCH_FILTER_MODE);
		domaininfo->dnsfilter_mode = strtoul(optarg, &end, 10);
		break;

	default:
		return 0;
	}
	return 1;
}

static void final_check(const struct ebt_u_entry *entry,
			const struct ebt_entry_match *match, const char *name,
			unsigned int hookmask, unsigned int time)
{}

static void print(const struct ebt_u_entry *entry,
		  const struct ebt_entry_match *match)
{
	ebt_domain_info *domaininfo = (ebt_domain_info *)match->data;

	printf("\r\ndomain:name %s", domaininfo->domain_name);
	printf(" dir %d", domaininfo->match_dir);
	printf(" mode %d", domaininfo->match_mode);
	printf(" type %d\n", domaininfo->match_type);
	printf(" filter index %d", domaininfo->dnsfilter_index);
	printf(" filter mode %d\n", domaininfo->dnsfilter_mode);
}

static int compare(const struct ebt_entry_match *m1,
		   const struct ebt_entry_match *m2)
{
	ebt_domain_info *info1 = (ebt_domain_info *)m1->data;
	ebt_domain_info *info2 = (ebt_domain_info *)m2->data;

	if (memcmp(info1, info2, sizeof(ebt_domain_info)) == 0)
		return 1;
	else
		return 0;
}

static struct ebt_u_match domain_match = {
	.name = "DOMAIN",
	.size = sizeof(ebt_domain_info),
	.help = print_help,
	.init = init,
	.parse = parse,
	.final_check = final_check,
	.print = print,
	.compare = compare,
	.extra_ops = opts,
};

static void _INIT(void)
{
	ebt_register_match(&domain_match);
}
