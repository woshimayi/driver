#ifndef BRIDGE_EBT_CFE_H
#define BRIDGE_EBT_CFE_H

#define HI_CFE_INVALID_PQ 8
#define HI_CFE_INVALID_SPRI 8
#define HI_CFE_INVALID_WAN_ID 8

enum {
	FWD_ACC_DISABLE = 0x1,
	FWD_CNT_ENABLE = (0x1 << 1),
	FWD_DSCP_M_ENABLE = (0x1 << 2),
};

struct ebt_cfe_info {
	unsigned short cfe_id;
	unsigned short fwd_flag;
	unsigned int rate;
	unsigned char pq;
	unsigned char wan_id;
	unsigned char spri;
	unsigned char dscp;
};
#define EBT_CFE_TARGET "cfe2"

#endif
