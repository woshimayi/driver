#ifndef BRIDGE_EBT_DOMAIN_TGT_H
#define BRIDGE_EBT_DOMAIN_TGT_H

#define MAX_IP_STR_LEN    16
#define MAX_IPV6_STR_LEN  48

struct ebt_dnsreply_info {
	unsigned char ip[MAX_IP_STR_LEN];
	unsigned char ipv6[MAX_IPV6_STR_LEN];
};

#endif //BRIDGE_EBT_DOMAIN_TGT_H
