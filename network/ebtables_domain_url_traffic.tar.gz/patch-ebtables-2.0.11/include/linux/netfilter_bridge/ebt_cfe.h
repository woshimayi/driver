#ifndef __LINUX_BRIDGE_EBT_CFE_H
#define __LINUX_BRIDGE_EBT_CFE_H


#define HI_CFE_INVALID_QID     0
#define HI_CFE_INVALID_PQ      8
#define HI_CFE_INVALID_GRO_ID  0
#define HI_CFE_INVALID_SPRI    8

#define FWD_MAX_LEN  8
#define ACC_MAX_LEN  4

struct ebt_cfe_info {
    char  fwd[FWD_MAX_LEN]; // accept or drop
    char  acc[ACC_MAX_LEN]; // yes or no
    unsigned short qid;
    unsigned char pq;
    unsigned char gro_id;
    unsigned char spri;
    unsigned char rsv[3];
};
#define EBT_CFE_TARGET "cfe"

#endif
