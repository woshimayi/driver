#ifndef BRIDGE_EBT_TRAFFIC_H
#define BRIDGE_EBT_TRAFFIC_H

struct ebt_traffic_info {
	int index;
	int mode;
};
#define EBT_TRAFFIC_TARGET "TRAFFIC"

#endif
