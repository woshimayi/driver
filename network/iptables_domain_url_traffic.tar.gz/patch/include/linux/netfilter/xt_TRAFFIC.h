#ifndef XT_TRAFFIC_TARGET_H
#define XT_TRAFFIC_TARGET_H

struct xt_traffic_tginfo {
	__u32 index;
	__u32 imode;
};

#endif /* XT_TRAFFIC_TARGET_H */
