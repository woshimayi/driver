#ifndef XT_DOMAIN_MATCH_H
#define XT_DOMAIN_MATCH_H

#define DOMAIN_MAX_LEN       128


#define XT_DOMAIN_MATCH_FULL  0x01
#define XT_DOMAIN_MATCH_SUB   0x02

#define XT_DOMAIN_DIR_BOTH    0x00
#define XT_DOMAIN_DIR_UP      0x01
#define XT_DOMAIN_DIR_DOWN    0x02


struct xt_domain {
	char            domain[DOMAIN_MAX_LEN];
	unsigned char   match_dir;       /* ����������ӦIPΪԴIP/Ŀ��IP/������ */
	unsigned char   match_mode;      /* ƥ��mode */
	unsigned char   match_type;      /* ƥ�䱨��type */
	uint32_t dnsfilter_index;
	uint32_t dnsfilter_mode;
};


#endif /* XT_DOMAIN_H */
