#ifndef XT_CFE_TARGET_H
#define XT_CFE_TARGET_H

#define HI_CFE_INVALID_PQ   8
#define HI_CFE_INVALID_SPRI 8
#define HI_CFE_INVALID_WAN_ID  8

enum {
	FWD_ACC_DISABLE = 0x1,
	FWD_CNT_ENABLE = (0x1 << 1),
	FWD_DSCP_M_ENABLE = (0x1 << 2),
};

struct xt_cfe_tginfo {
	unsigned short cfe_id;
	unsigned short fwd_flag;
	unsigned int   rate;
	unsigned char pq;
	unsigned char wan_id;
	unsigned char spri;
	unsigned char dscp;
};

#endif /* XT_CFE_TARGET_H */
