#ifndef _XT_URLREDIRECT_TARGET_H
#define _XT_URLREDIRECT_TARGET_H

#define URL_MAX_LEN  128

struct xt_urlredirect_tginfo {
	char ac_redirect_url[URL_MAX_LEN];
	__u16 us_redirect_port;
};

#endif /* _XT_URLREDIRECT_TARGET_H */
