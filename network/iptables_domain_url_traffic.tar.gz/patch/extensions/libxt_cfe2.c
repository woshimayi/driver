#include <sys/socket.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <xtables.h>
#include <linux/netfilter.h>
#include <linux/netfilter/x_tables.h>
#include <linux/netfilter/xt_cfe2.h>

enum {
	OPT_CFE_ID = 0,
	OPT_FWD_FLAG,
	OPT_RATE,
	OPT_PQ_VAL,
	OPT_WAN_ID,
	OPT_SPRI_VAL,
};

#define s struct xt_cfe_tginfo
static const struct xt_option_entry cfe_tg_opts[] = {
	{
		.name = "cfe_id", .id = OPT_CFE_ID, .type = XTTYPE_UINT16,
		.flags = XTOPT_MAND | XTOPT_PUT, XTOPT_POINTER(s, cfe_id)
	},
	{
		.name = "fwd", .id = OPT_FWD_FLAG, .type = XTTYPE_UINT16,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, fwd_flag)
	},
	{
		.name = "rate", .id = OPT_RATE, .type = XTTYPE_UINT32,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, rate)
	},
	{
		.name = "pq", .id = OPT_PQ_VAL, .type = XTTYPE_UINT8,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, pq)
	},
	{
		.name = "wan_id", .id = OPT_WAN_ID, .type = XTTYPE_UINT8,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, wan_id)
	},
	{
		.name = "spri", .id = OPT_SPRI_VAL, .type = XTTYPE_UINT8,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, spri)
	},
	XTOPT_TABLEEND,
};
#undef s

static void cfe_tg_help(void)
{
	printf("cfe2 qos target options:\n"
		"  --cfe_id cfe flow id from [0, 65535]\n"
		"  --fwd fwd flag( bit0 not acc, bit1 flow cnt, bit2 dscp remark) \n"
		"  --rate rate limit value, in kbps\n"
		"  --pq  specify pq modify value, in range [0,7]\n"
		"  --wan_id specify a wan connection id\n"
		"  --spri specify outer 802.1p, in range [0,7]\n"
		"\n");
	return;
}

static void cfe_tg_print(const void *ip, const struct xt_entry_target *target, int numeric)
{
	const struct xt_cfe_tginfo *info = (struct xt_cfe_tginfo *)target->data;

	printf(" CFE_ID:%u", info->cfe_id);
	printf(" FWD:");
	if (info->fwd_flag & FWD_ACC_DISABLE) {
		printf(" no_acc");
	}
	if (info->fwd_flag & FWD_CNT_ENABLE) {
		printf(" hw_cnt");
	}
	if (info->pq >= HI_CFE_INVALID_PQ) {
		printf(" PQ %u", info->pq);
	}
	if (info->pq >= HI_CFE_INVALID_SPRI) {
		printf(" PRI %u", info->spri);
	}
	if (info->rate > 0) {
		printf(" RATE %u", info->rate);
	}
	if (info->wan_id > 0) {
		printf(" WAN %u", info->wan_id);
	}
	return;
}

static void cfe_tg_save(const void *ip, const struct xt_entry_target *target)
{
	struct xt_cfe_tginfo *info = (struct xt_cfe_tginfo *)target->data;
	printf("--cfe_id:%u ", info->cfe_id);
	printf("--fwd:%u ", info->fwd_flag);
	printf("--rate:%u ", info->rate);
	printf("--pq:%u ", info->pq);
	printf("--wan_id:%u ", info->wan_id);
	printf("--spri:%u ", info->spri);
	return;
}

static void cfe_tg_init(struct xt_entry_target *target)
{
	struct xt_cfe_tginfo *info = (struct xt_cfe_tginfo *)target->data;
	info->cfe_id = 0;
	info->fwd_flag = 0;
	info->rate = 0;
	info->pq  = HI_CFE_INVALID_PQ;
	info->wan_id = HI_CFE_INVALID_WAN_ID;
	info->spri = HI_CFE_INVALID_SPRI;
	return;
}

static struct xtables_target cfe_tg_reg = {
	.name          = "cfe2",
	.version       = XTABLES_VERSION,
	.revision      = 1,
	.family        = NFPROTO_UNSPEC,
	.size          = XT_ALIGN(sizeof(struct xt_cfe_tginfo)),
	.userspacesize = XT_ALIGN(sizeof(struct xt_cfe_tginfo)),
	.help          = cfe_tg_help,
	.init          = cfe_tg_init,
	.print         = cfe_tg_print,
	.save          = cfe_tg_save,
	.x6_parse      = xtables_option_parse,
	.x6_options    = cfe_tg_opts,
};


void _init(void)
{
	xtables_register_target(&cfe_tg_reg);
}
