
#include <sys/socket.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xtables.h>
#include <linux/netfilter.h>
#include <linux/netfilter/x_tables.h>
#include <linux/netfilter/xt_URLREDIRECT.h>

enum {
	O_REDIRECT_URL = 0,
	O_REDIRECT_PORT
};

#define s struct xt_urlredirect_tginfo
static const struct xt_option_entry urlredirect_tg_opts[] = {
	{
		.name = "url", .id = O_REDIRECT_URL, .type = XTTYPE_STRING,
		.flags = XTOPT_MAND | XTOPT_PUT, XTOPT_POINTER(s, ac_redirect_url)
	},
	{
		.name = "port", .id = O_REDIRECT_PORT, .type = XTTYPE_UINT16,
		.flags = XTOPT_MAND | XTOPT_PUT, XTOPT_POINTER(s, us_redirect_port)
	},
	XTOPT_TABLEEND,
};
#undef s

static void urlredirect_tg_help(void)
{
	printf("URL REDIRECT target options:\n"
	       "  --url [domain or ipaddr]\n"
	       "  --port [must be 80/8080/18080]\n"
	       "\n");
}

static void urlredirect_tg_print(const void *ip, const struct xt_entry_target *target,
				 int numeric)
{
	const struct xt_urlredirect_tginfo *info = (const void *)target->data;
	printf("redirect to :%s:%u\n", info->ac_redirect_url, info->us_redirect_port);
}


static void urlredirect_tg_save(const void *ip, const struct xt_entry_target *target)
{
	const struct xt_urlredirect_tginfo *info = (const void *)target->data;

	printf("--url :%s ", info->ac_redirect_url);
	printf("--port :%u \n", info->us_redirect_port);
}


static struct xtables_target urlredirect_tg_reg = {
	.name          = "URLREDIRECT",
	.version       = XTABLES_VERSION,
	.revision      = 1,
	.family        = NFPROTO_UNSPEC,
	.size          = XT_ALIGN(sizeof(struct xt_urlredirect_tginfo)),
	.userspacesize = XT_ALIGN(sizeof(struct xt_urlredirect_tginfo)),
	.help          = urlredirect_tg_help,
	.print         = urlredirect_tg_print,
	.save          = urlredirect_tg_save,
	.x6_parse      = xtables_option_parse,
	.x6_options    = urlredirect_tg_opts,
};


void _init(void)
{
	xtables_register_target(&urlredirect_tg_reg);
}
