
#include <sys/socket.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


#include <xtables.h>
#include <linux/netfilter.h>
#include <linux/netfilter/x_tables.h>
#include <linux/netfilter/xt_cfe.h>

enum {
	O_FWD_STRING,
    O_ACC_STRING,
	O_QID_IDX,
    O_PQ_VAL,
    O_GRO_ID,
    O_SPRI_VAL,
};

#define s struct xt_cfe_tginfo
static const struct xt_option_entry cfe_tg_opts[] = {
	{.name = "fwd", .id = O_FWD_STRING, .type = XTTYPE_STRING,
	 .flags = XTOPT_PUT, XTOPT_POINTER(s, fwd)},
    {.name = "acc", .id = O_ACC_STRING, .type = XTTYPE_STRING,
     .flags = XTOPT_PUT, XTOPT_POINTER(s, acc)},
    {.name = "qid", .id = O_QID_IDX, .type = XTTYPE_UINT16,
     .flags = XTOPT_PUT, XTOPT_POINTER(s, qid)},
    {.name = "pq", .id = O_PQ_VAL, .type = XTTYPE_UINT8,
     .flags = XTOPT_PUT, XTOPT_POINTER(s, pq)},
    {.name = "gro_id", .id = O_GRO_ID, .type = XTTYPE_UINT8,
     .flags = XTOPT_PUT, XTOPT_POINTER(s, gro_id)},
    {.name = "spri", .id = O_SPRI_VAL, .type = XTTYPE_UINT8,
     .flags = XTOPT_PUT, XTOPT_POINTER(s, spri)},
	 XTOPT_TABLEEND,
};
#undef s

static void cfe_tg_help(void)
{
	printf("cfe qos target options:\n"
           "  --fwd accept or drop, accept by default\n"
           "  --acc yes or no, yes by default\n"
           "  --qid must allocate first, as index specify a qid entry\n"
           "  --pq  specify pq modify value\n"
           "  --gro_id specify a gro id\n"
           "  --spri specify outer 802.1p, in range [0,7]\n"
           "\n");
    return;
}

static void cfe_tg_print(const void *ip, const struct xt_entry_target *target, int numeric)
{
    char pq[6] = {0};
    char spri[6] = {0};
    char gro[6] = {0};
	const struct xt_cfe_tginfo *info = (struct xt_cfe_tginfo *)target->data;

    if (info->pq >= HI_CFE_INVALID_PQ){
        sprintf(pq, "no");
    }else {
        sprintf(pq, "%u", info->pq);
    }

    if (info->gro_id >= HI_CFE_INVALID_GRO_ID){
        sprintf(gro, "no");
    }else {
        sprintf(gro, "%u", info->gro_id);
    }

    if (info->spri >= HI_CFE_INVALID_SPRI){
        sprintf(spri, "no");
    }else {
        sprintf(spri, "%u", info->spri);
    }

	printf(" fwd:%s acc:%s qid:%u pq:%s gro:%s spri:%s",
	    info->fwd, info->acc, info->qid, pq, gro, spri);
    return;
}

static void cfe_tg_save(const void *ip, const struct xt_entry_target *target)
{
	struct xt_cfe_tginfo *info = (struct xt_cfe_tginfo *)target->data;
	printf("--fwd:%s ", info->fwd);
	printf("--acc:%s ", info->acc);
	printf("--qid:%u ", info->qid);
	printf("--pq:%u " , info->pq);
	printf("--gro_id:%u " , info->gro_id);
	printf("--spri:%u " , info->spri);
    return;
}

static void cfe_tg_init(struct xt_entry_target *target)
{
	struct xt_cfe_tginfo *info = (struct xt_cfe_tginfo *)target->data;
    strncpy(info->fwd, "accept", FWD_MAX_LEN - 1);
    strncpy(info->acc, "yes",    ACC_MAX_LEN - 1);
    info->qid = HI_CFE_INVALID_QID;
    info->pq  = HI_CFE_INVALID_PQ;
    info->gro_id = HI_CFE_INVALID_GRO_ID;
    info->spri = HI_CFE_INVALID_SPRI;
    return;
}

static struct xtables_target cfe_tg_reg = {
		.name          = "cfe",
		.version       = XTABLES_VERSION,
		.revision      = 1,
		.family        = NFPROTO_UNSPEC,
		.size          = XT_ALIGN(sizeof(struct xt_cfe_tginfo)),
		.userspacesize = XT_ALIGN(sizeof(struct xt_cfe_tginfo)),
		.help          = cfe_tg_help,
		.init          = cfe_tg_init,
		.print         = cfe_tg_print,
		.save          = cfe_tg_save,
		.x6_parse      = xtables_option_parse,
		.x6_options    = cfe_tg_opts,
};


void _init(void)
{
	xtables_register_target(&cfe_tg_reg);
}
