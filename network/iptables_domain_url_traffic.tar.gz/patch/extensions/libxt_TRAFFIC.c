
#include <sys/socket.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xtables.h>
#include <linux/netfilter.h>
#include <linux/netfilter/x_tables.h>
#include <linux/netfilter/xt_TRAFFIC.h>

enum {
	O_INDEX = 0,
	O_IMODE,
};

#define s struct xt_traffic_tginfo
static const struct xt_option_entry traffic_tg_opts[] = {
	{
		.name = "index", .id = O_INDEX, .type = XTTYPE_UINT32,
		.flags = XTOPT_MAND | XTOPT_PUT, XTOPT_POINTER(s, index)
	},
	{
		.name = "mode", .id = O_IMODE, .type = XTTYPE_UINT32,
		.flags = XTOPT_MAND | XTOPT_PUT, XTOPT_POINTER(s, imode)
	},
	XTOPT_TABLEEND,
};
#undef s

static void traffic_tg_help(void)
{
	printf(
		"TAFFIC target options:\n"
		"  --index INDEX    The index of rule ,this will return to APP\n"
		"TAFFIC target options:\n"
		"  --mode MODE     0: http process 1: mirror process \n"
		"\n");
}

static void traffic_tg_print(const void *ip, const struct xt_entry_target *target,
			     int numeric)
{
	const struct xt_traffic_tginfo *info = (const void *)target->data;

	printf(" TRAFFIC rule index :%u \n", info->index);
	printf(" TRAFFIC rule imode :%u \n", info->imode);

}


static void traffic_tg_save(const void *ip, const struct xt_entry_target *target)
{
	const struct xt_traffic_tginfo *info = (const void *)target->data;

	printf("--index %u ", info->index);
	printf("--imode %u ", info->imode);
}


static struct xtables_target traffic_tg_reg = {
	.name          = "TRAFFIC",
	.version       = XTABLES_VERSION,
	.revision      = 1,
	.family        = NFPROTO_UNSPEC,
	.size          = XT_ALIGN(sizeof(struct xt_traffic_tginfo)),
	.userspacesize = XT_ALIGN(sizeof(struct xt_traffic_tginfo)),
	.help          = traffic_tg_help,
	.print         = traffic_tg_print,
	.save          = traffic_tg_save,
	.x6_parse      = xtables_option_parse,
	.x6_options    = traffic_tg_opts,
};


void _init(void)
{
	xtables_register_target(&traffic_tg_reg);
}
