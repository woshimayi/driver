#include <sys/socket.h>
#include <getopt.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <xtables.h>
#include <linux/netfilter.h>
#include <linux/netfilter/x_tables.h>
#include <linux/netfilter/xt_DOMAIN.h>

enum {
	O_DOMAIN_NAME = 0,
	O_DOMAIN_MODE  = 1,
	O_DOMAIN_DIR   = 2,
	O_DOMAIN_TYPE  = 3,
	O_DOMAIN_FILTER_INDEX = 4,
	O_DOMAIN_FILTER_MODE = 5,
};

static void domain_help(void)
{
	printf("domain match options:\n"
	       "--name           NAME         atch a domain name in dns reply pkt\n"
	       "--match-dir      DIR          IP address of Domain in direction(1 for up, 2 for down, 3 for both(default)\n"
	       "--match-mode     MODE         Match mode, 0 for full match(default), 1 for sub match\n"
	       "--match-type     TYPE         Match type, 1 for ip address in NO DNS Pkt , 2 domain name in DNS pkt, 3 for both(default) and 4 for dns filter\n"
	       "--filter-index   FILTER_INDEX DNS filter index, 0xffffffff(default)\n"
	       "--filter-mode    FILTER_MODE  DNS filter mode, 0 for blacklist(default), 1 for whitelist\n");
}

#define s struct xt_domain
static const struct xt_option_entry domain_opts[] = {
	{
		.name = "name", .id = O_DOMAIN_NAME, .type = XTTYPE_STRING,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, domain)
	},
	{
		.name = "match-mode", .id = O_DOMAIN_MODE, .type = XTTYPE_UINT8,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, match_mode)
	},
	{
		.name = "match-dir", .id = O_DOMAIN_DIR, .type = XTTYPE_UINT8,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, match_dir)
	},
	{
		.name = "match-type", .id = O_DOMAIN_TYPE, .type = XTTYPE_UINT8,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, match_type)
	},
	{
		.name = "filter-index", .id = O_DOMAIN_FILTER_INDEX, .type = XTTYPE_UINT32,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, dnsfilter_index)
	},
	{
		.name = "filter-mode", .id = O_DOMAIN_FILTER_MODE, .type = XTTYPE_UINT32,
		.flags = XTOPT_PUT, XTOPT_POINTER(s, dnsfilter_mode)
	},
	XTOPT_TABLEEND,
};
#undef s


static void domain_init(struct xt_entry_match *m)
{
	struct xt_domain *domaininfo = (struct xt_domain *)m->data;

	domaininfo->domain[0] = 0;
	domaininfo->match_dir  = 3;
	domaininfo->match_mode = 0;
	domaininfo->match_type = 3;
	domaininfo->dnsfilter_index = 0xffffffff;
	domaininfo->dnsfilter_mode = 0;
}

static void domain_print(const void *ip, const struct xt_entry_match *match, int numeric)
{
	const struct xt_domain *domaininfo = (struct xt_domain *)match->data;
	printf("\r\ndomain:name %s", domaininfo->domain);
	printf(" dir %d", domaininfo->match_dir);
	printf(" mode %d", domaininfo->match_mode);
	printf(" type %d\n", domaininfo->match_type);
	printf(" filter index %d", domaininfo->dnsfilter_index);
	printf(" filter mode %d\n", domaininfo->dnsfilter_mode);
}

static void domain_save(const void *ip, const struct xt_entry_match *match)
{
	const struct xt_domain *domaininfo = (struct xt_domain *)match->data;
	printf(" --name %s", domaininfo->domain);
	printf(" --match-mode %d", domaininfo->match_mode);
	printf(" --match-dir %d", domaininfo->match_dir);
	printf(" --match-type %d", domaininfo->match_type);
	printf(" --filter index %d", domaininfo->dnsfilter_index);
	printf(" --filter mode %d\n", domaininfo->dnsfilter_mode);
}

static struct xtables_match domain_match = {
	.family		= NFPROTO_UNSPEC,
	.name		= "DOMAIN",
	.revision      = 1,
	.version	= XTABLES_VERSION,
	.size		= XT_ALIGN(sizeof(struct xt_domain)),
	.userspacesize	= XT_ALIGN(sizeof(struct xt_domain)),
	.help		= domain_help,
	.init		= domain_init,
	.print		= domain_print,
	.save		= domain_save,
	.x6_parse	= xtables_option_parse,
	.x6_options	= domain_opts,
};

void _init(void)
{
	xtables_register_match(&domain_match);
}
